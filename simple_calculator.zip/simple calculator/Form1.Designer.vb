﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnmod = New System.Windows.Forms.Button()
        Me.btnpower = New System.Windows.Forms.Button()
        Me.btninteger = New System.Windows.Forms.Button()
        Me.btndivide = New System.Windows.Forms.Button()
        Me.btntimes = New System.Windows.Forms.Button()
        Me.btnminus = New System.Windows.Forms.Button()
        Me.btnadd = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.lblsymbol = New System.Windows.Forms.Label()
        Me.txtoperand2 = New System.Windows.Forms.TextBox()
        Me.txtoperand1 = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lblresult = New System.Windows.Forms.Label()
        Me.btnclear = New System.Windows.Forms.Button()
        Me.btnexit = New System.Windows.Forms.Button()
        Me.btnpercentage = New System.Windows.Forms.Button()
        Me.btnroot = New System.Windows.Forms.Button()
        Me.btnsquare = New System.Windows.Forms.Button()
        Me.btnphytagoras = New System.Windows.Forms.Button()
        Me.btnsin = New System.Windows.Forms.Button()
        Me.btncos = New System.Windows.Forms.Button()
        Me.btntan = New System.Windows.Forms.Button()
        Me.btnareatriangle = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnareatriangle)
        Me.GroupBox1.Controls.Add(Me.btntan)
        Me.GroupBox1.Controls.Add(Me.btncos)
        Me.GroupBox1.Controls.Add(Me.btnsin)
        Me.GroupBox1.Controls.Add(Me.btnphytagoras)
        Me.GroupBox1.Controls.Add(Me.btnsquare)
        Me.GroupBox1.Controls.Add(Me.btnroot)
        Me.GroupBox1.Controls.Add(Me.btnpercentage)
        Me.GroupBox1.Controls.Add(Me.btnmod)
        Me.GroupBox1.Controls.Add(Me.btnpower)
        Me.GroupBox1.Controls.Add(Me.btninteger)
        Me.GroupBox1.Controls.Add(Me.btndivide)
        Me.GroupBox1.Controls.Add(Me.btntimes)
        Me.GroupBox1.Controls.Add(Me.btnminus)
        Me.GroupBox1.Controls.Add(Me.btnadd)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(273, 472)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Operators"
        '
        'btnmod
        '
        Me.btnmod.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnmod.Location = New System.Drawing.Point(6, 279)
        Me.btnmod.Name = "btnmod"
        Me.btnmod.Size = New System.Drawing.Size(237, 55)
        Me.btnmod.TabIndex = 7
        Me.btnmod.Text = "&MOD"
        Me.btnmod.UseVisualStyleBackColor = True
        '
        'btnpower
        '
        Me.btnpower.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnpower.Location = New System.Drawing.Point(87, 157)
        Me.btnpower.Name = "btnpower"
        Me.btnpower.Size = New System.Drawing.Size(75, 55)
        Me.btnpower.TabIndex = 6
        Me.btnpower.Text = "&^"
        Me.btnpower.UseVisualStyleBackColor = True
        '
        'btninteger
        '
        Me.btninteger.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btninteger.Location = New System.Drawing.Point(6, 157)
        Me.btninteger.Name = "btninteger"
        Me.btninteger.Size = New System.Drawing.Size(75, 55)
        Me.btninteger.TabIndex = 5
        Me.btninteger.Text = "&\"
        Me.btninteger.UseVisualStyleBackColor = True
        '
        'btndivide
        '
        Me.btndivide.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btndivide.Location = New System.Drawing.Point(87, 96)
        Me.btndivide.Name = "btndivide"
        Me.btndivide.Size = New System.Drawing.Size(75, 55)
        Me.btndivide.TabIndex = 4
        Me.btndivide.Text = "&/"
        Me.btndivide.UseVisualStyleBackColor = True
        '
        'btntimes
        '
        Me.btntimes.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btntimes.Location = New System.Drawing.Point(6, 96)
        Me.btntimes.Name = "btntimes"
        Me.btntimes.Size = New System.Drawing.Size(75, 55)
        Me.btntimes.TabIndex = 3
        Me.btntimes.Text = "&*"
        Me.btntimes.UseVisualStyleBackColor = True
        '
        'btnminus
        '
        Me.btnminus.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnminus.Location = New System.Drawing.Point(87, 35)
        Me.btnminus.Name = "btnminus"
        Me.btnminus.Size = New System.Drawing.Size(75, 55)
        Me.btnminus.TabIndex = 2
        Me.btnminus.Text = "&-"
        Me.btnminus.UseVisualStyleBackColor = True
        '
        'btnadd
        '
        Me.btnadd.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnadd.Location = New System.Drawing.Point(6, 35)
        Me.btnadd.Name = "btnadd"
        Me.btnadd.Size = New System.Drawing.Size(75, 55)
        Me.btnadd.TabIndex = 1
        Me.btnadd.Text = "&+"
        Me.btnadd.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnexit)
        Me.GroupBox2.Controls.Add(Me.btnclear)
        Me.GroupBox2.Controls.Add(Me.lblresult)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(Me.lblsymbol)
        Me.GroupBox2.Controls.Add(Me.txtoperand2)
        Me.GroupBox2.Controls.Add(Me.txtoperand1)
        Me.GroupBox2.Controls.Add(Me.Label2)
        Me.GroupBox2.Controls.Add(Me.Label1)
        Me.GroupBox2.Location = New System.Drawing.Point(291, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(422, 304)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Operation"
        '
        'lblsymbol
        '
        Me.lblsymbol.AutoSize = True
        Me.lblsymbol.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblsymbol.Location = New System.Drawing.Point(97, 73)
        Me.lblsymbol.Name = "lblsymbol"
        Me.lblsymbol.Size = New System.Drawing.Size(0, 29)
        Me.lblsymbol.TabIndex = 4
        '
        'txtoperand2
        '
        Me.txtoperand2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtoperand2.Location = New System.Drawing.Point(88, 114)
        Me.txtoperand2.Name = "txtoperand2"
        Me.txtoperand2.Size = New System.Drawing.Size(283, 26)
        Me.txtoperand2.TabIndex = 3
        '
        'txtoperand1
        '
        Me.txtoperand1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!)
        Me.txtoperand1.Location = New System.Drawing.Point(88, 35)
        Me.txtoperand1.Name = "txtoperand1"
        Me.txtoperand1.Size = New System.Drawing.Size(283, 26)
        Me.txtoperand1.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label2.Location = New System.Drawing.Point(6, 120)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Operand 2"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.0!)
        Me.Label1.Location = New System.Drawing.Point(6, 41)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(76, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Operand 1"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(6, 191)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 20)
        Me.Label3.TabIndex = 5
        Me.Label3.Text = "Result"
        '
        'lblresult
        '
        Me.lblresult.AutoSize = True
        Me.lblresult.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!)
        Me.lblresult.Location = New System.Drawing.Point(97, 182)
        Me.lblresult.Name = "lblresult"
        Me.lblresult.Size = New System.Drawing.Size(0, 29)
        Me.lblresult.TabIndex = 6
        '
        'btnclear
        '
        Me.btnclear.Location = New System.Drawing.Point(88, 237)
        Me.btnclear.Name = "btnclear"
        Me.btnclear.Size = New System.Drawing.Size(91, 36)
        Me.btnclear.TabIndex = 7
        Me.btnclear.Text = "Clea&r"
        Me.btnclear.UseVisualStyleBackColor = True
        '
        'btnexit
        '
        Me.btnexit.Location = New System.Drawing.Point(223, 237)
        Me.btnexit.Name = "btnexit"
        Me.btnexit.Size = New System.Drawing.Size(91, 36)
        Me.btnexit.TabIndex = 8
        Me.btnexit.Text = "&Exit"
        Me.btnexit.UseVisualStyleBackColor = True
        '
        'btnpercentage
        '
        Me.btnpercentage.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnpercentage.Location = New System.Drawing.Point(168, 35)
        Me.btnpercentage.Name = "btnpercentage"
        Me.btnpercentage.Size = New System.Drawing.Size(75, 55)
        Me.btnpercentage.TabIndex = 8
        Me.btnpercentage.Text = "&%"
        Me.btnpercentage.UseVisualStyleBackColor = True
        '
        'btnroot
        '
        Me.btnroot.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnroot.Location = New System.Drawing.Point(168, 157)
        Me.btnroot.Name = "btnroot"
        Me.btnroot.Size = New System.Drawing.Size(75, 55)
        Me.btnroot.TabIndex = 9
        Me.btnroot.Text = "√"
        Me.btnroot.UseVisualStyleBackColor = True
        '
        'btnsquare
        '
        Me.btnsquare.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnsquare.Location = New System.Drawing.Point(168, 96)
        Me.btnsquare.Name = "btnsquare"
        Me.btnsquare.Size = New System.Drawing.Size(75, 55)
        Me.btnsquare.TabIndex = 10
        Me.btnsquare.Text = "^&2"
        Me.btnsquare.UseVisualStyleBackColor = True
        '
        'btnphytagoras
        '
        Me.btnphytagoras.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.0!, System.Drawing.FontStyle.Bold)
        Me.btnphytagoras.Location = New System.Drawing.Point(6, 340)
        Me.btnphytagoras.Name = "btnphytagoras"
        Me.btnphytagoras.Size = New System.Drawing.Size(237, 55)
        Me.btnphytagoras.TabIndex = 11
        Me.btnphytagoras.Text = "&Phytagoras"
        Me.btnphytagoras.UseVisualStyleBackColor = True
        '
        'btnsin
        '
        Me.btnsin.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnsin.Location = New System.Drawing.Point(6, 218)
        Me.btnsin.Name = "btnsin"
        Me.btnsin.Size = New System.Drawing.Size(75, 55)
        Me.btnsin.TabIndex = 12
        Me.btnsin.Text = "&sin"
        Me.btnsin.UseVisualStyleBackColor = True
        '
        'btncos
        '
        Me.btncos.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btncos.Location = New System.Drawing.Point(87, 218)
        Me.btncos.Name = "btncos"
        Me.btncos.Size = New System.Drawing.Size(75, 55)
        Me.btncos.TabIndex = 13
        Me.btncos.Text = "&cos"
        Me.btncos.UseVisualStyleBackColor = True
        '
        'btntan
        '
        Me.btntan.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btntan.Location = New System.Drawing.Point(168, 218)
        Me.btntan.Name = "btntan"
        Me.btntan.Size = New System.Drawing.Size(75, 55)
        Me.btntan.TabIndex = 14
        Me.btntan.Text = "&tan"
        Me.btntan.UseVisualStyleBackColor = True
        '
        'btnareatriangle
        '
        Me.btnareatriangle.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.0!, System.Drawing.FontStyle.Bold)
        Me.btnareatriangle.Location = New System.Drawing.Point(6, 401)
        Me.btnareatriangle.Name = "btnareatriangle"
        Me.btnareatriangle.Size = New System.Drawing.Size(237, 55)
        Me.btnareatriangle.TabIndex = 15
        Me.btnareatriangle.Text = "&A▷"
        Me.btnareatriangle.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(728, 496)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Operators"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents btnmod As Button
    Friend WithEvents btnpower As Button
    Friend WithEvents btninteger As Button
    Friend WithEvents btndivide As Button
    Friend WithEvents btntimes As Button
    Friend WithEvents btnminus As Button
    Friend WithEvents btnadd As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents lblsymbol As Label
    Friend WithEvents txtoperand2 As TextBox
    Friend WithEvents txtoperand1 As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents btnexit As Button
    Friend WithEvents btnclear As Button
    Friend WithEvents lblresult As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents btnsquare As Button
    Friend WithEvents btnroot As Button
    Friend WithEvents btnpercentage As Button
    Friend WithEvents btnphytagoras As Button
    Friend WithEvents btntan As Button
    Friend WithEvents btncos As Button
    Friend WithEvents btnsin As Button
    Friend WithEvents btnareatriangle As Button
End Class
