﻿Public Class Form1
    Private Sub btnadd_Click(sender As Object, e As EventArgs) Handles btnadd.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 + operand2

        lblsymbol.Text = "+"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnminus_Click(sender As Object, e As EventArgs) Handles btnminus.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 - operand2

        lblsymbol.Text = "-"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btntimes_Click(sender As Object, e As EventArgs) Handles btntimes.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 * operand2

        lblsymbol.Text = "*"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btndivide_Click(sender As Object, e As EventArgs) Handles btndivide.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 / operand2

        lblsymbol.Text = "/"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btninteger_Click(sender As Object, e As EventArgs) Handles btninteger.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 \ operand2

        lblsymbol.Text = "\"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnpower_Click(sender As Object, e As EventArgs) Handles btnpower.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 ^ operand2

        lblsymbol.Text = "^"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnmod_Click(sender As Object, e As EventArgs) Handles btnmod.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = operand1 Mod operand2

        lblsymbol.Text = "Mod"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnclear_Click(sender As Object, e As EventArgs) Handles btnclear.Click
        txtoperand1.Clear()
        txtoperand2.Clear()
        lblresult.Text = ""
        lblsymbol.Text = ""
    End Sub
    Private Sub btnexit_Click(sender As Object, e As EventArgs) Handles btnexit.Click
        Me.Close()
    End Sub

    Private Sub btnpercentage_Click(sender As Object, e As EventArgs) Handles btnpercentage.Click
        Dim operand1, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        result = operand1 / 100

        lblsymbol.Text = "%"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnsquare_Click(sender As Object, e As EventArgs) Handles btnsquare.Click
        Dim operand1, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        result = operand1 ^ 2

        lblsymbol.Text = "^2"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnroot_Click(sender As Object, e As EventArgs) Handles btnroot.Click
        Dim operand1, result As Double
        operand1 = Double.Parse(txtoperand1.Text)

        result = operand1 ^ (1 / 2)
        lblsymbol.Text = "√"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnphytagoras_Click(sender As Object, e As EventArgs) Handles btnphytagoras.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = ((operand1 ^ 2) + (operand2 ^ 2)) ^ (1 / 2)

        lblsymbol.Text = "Phytagoras"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnareatriangle_Click(sender As Object, e As EventArgs) Handles btnareatriangle.Click
        Dim operand1, operand2, result As Double
        operand1 = Double.Parse(txtoperand1.Text)
        operand2 = Double.Parse(txtoperand2.Text)
        result = (operand1 * operand2) / 2

        lblsymbol.Text = "A▷"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btnsin_Click(sender As Object, e As EventArgs) Handles btnsin.Click
        Dim operand1, operand2, result, pi, getradian As Double
        pi = 3.14159265358979
        operand1 = txtoperand1.Text
        getradian = operand1 * (pi / 180)
        result = Math.Sin(getradian)
        lblsymbol.Text = "Sin"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btncos_Click(sender As Object, e As EventArgs) Handles btncos.Click
        Dim operand1, operand2, result, pi, getradian As Double
        operand1 = Double.Parse(txtoperand1.Text)
        getradian = 3.14
        If operand1 = 90 Then
            result = 0

        Else
            result = Math.Cos(operand1 * getradian / 180)

        End If
        lblsymbol.Text = "Cos"
        lblresult.Text = result.ToString
    End Sub

    Private Sub btntan_Click(sender As Object, e As EventArgs) Handles btntan.Click
        Dim operand1, operand2, result, pi, getradian As Double
        pi = 3.14159265358979
        operand1 = txtoperand1.Text
        getradian = operand1 * (pi / 180)
        result = Math.Tan(getradian)
        lblsymbol.Text = "Tan"
        lblresult.Text = result.ToString
    End Sub
End Class
